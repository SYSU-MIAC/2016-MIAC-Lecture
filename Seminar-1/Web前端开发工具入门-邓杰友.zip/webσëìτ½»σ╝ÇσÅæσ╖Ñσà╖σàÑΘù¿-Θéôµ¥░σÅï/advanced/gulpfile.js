var
	gulp = require('gulp'),
    jade = require('gulp-jade'),
    sass = require('gulp-sass'),
    autoprefixer = require('gulp-autoprefixer'),
    minifycss = require('gulp-minify-css'),
    imagemin = require('gulp-imagemin'),
    rename = require('gulp-rename'),
    cache = require('gulp-cache'),
	livescript = require('gulp-livescript'),
	uglify = require('gulp-uglify'),
    notify = require('gulp-notify');

gulp.task('html', function() {
	return gulp.src('src/view/*.jade')
        .pipe(jade())
        .pipe(gulp.dest('dist/view'))
        .pipe(notify({message: 'HTML task complete'}));
});

gulp.task('styles', function () {
    return gulp.src('src/sass/*.sass')
        .pipe(sass({outputStyle: 'expanded'}))
        .pipe(autoprefixer('last 2 version'))
        .pipe(gulp.dest('dist/assets/css'))
        .pipe(rename({suffix: '.min'}))
        .pipe(minifycss())
        .pipe(gulp.dest('dist/assets/css'))
        .pipe(notify({message: 'Styles task complete'}));
});


gulp.task('scripts', function () {
	return gulp.src('src/js/*.ls')
		.pipe(livescript())
		.pipe(gulp.dest('dist/assets/js'))
		.pipe(rename({suffix: '.min'}))
		.pipe(uglify())
		.pipe(gulp.dest('dist/assets/js'))
		.pipe(notify({message: 'Scripts task complete'}));
});

gulp.task('images', function () {
   return gulp.src('src/img/*')
       .pipe(cache(imagemin({optimizationLevel: 5, progressive: true, interlaced: true})))
       .pipe(gulp.dest('dist/assets/img'))
       .pipe(notify({message: 'Images task complete'}));
});

gulp.task('default', ['watch'], function() {
	gulp.start('html', 'styles', 'scripts', 'images');
});

gulp.task('watch', function() {
	gulp.watch('src/view/*', ['html']);
    gulp.watch('src/sass/*', ['styles']);
	gulp.watch('src/js/*', ['scripts']);
});