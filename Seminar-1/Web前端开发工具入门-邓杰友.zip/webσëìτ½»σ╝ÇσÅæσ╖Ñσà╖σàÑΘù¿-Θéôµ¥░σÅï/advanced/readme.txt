1. 在官网上下载相应版本的node 
2. 全局安装gulp， 打开命令行输入   "npm install -g gulp " （linux或osx下要加sudo）
3. 在当前文件夹启动命令行，运行 "npm install" （安装package.json文件中的依赖）
4. 当前文件夹中启动命令行运行  "gulp"